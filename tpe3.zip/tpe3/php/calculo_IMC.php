<?php

if(isset($_GET['peso']) && isset($_GET['altura'])){

$peso = $_POST['peso'] / 100;
$altura = $_POST['altura'];
$calculoIMC = calculoIMC($peso, $altura);
$calculoResultado = calculoResultado($calculoIMC);


echo $altura;
echo "Índice de Masa Corporal". $calculo_IMC. "estado". $calculoResultado;
    } else {
        echo "Ingresar los datos requeridos";
}


function calculoIMC(float $peso, float $altura): float {
    return $peso / ($altura * $altura);
}


function calculoResultado(float $imc) : string {
    if ($imc <= 15){
        return "Cuadro de Delgadez muy Severa";

    } else if ($imc >= 15 && $imc <= 15.9){
        return "Cuadro de Delgadez Severa";

    } else if ($imc >= 16 && $imc <= 18.4){
        return "Cuadro de Delgadez";

    } else if ($imc >= 18.5 && $imc <= 24.9){
        return "Valor Normal";

    } else if ($imc >= 25 && $imc <= 29.9){
        return "Cuadro de Sobrepeso";

    } else if ($imc >= 30 && $imc <= 34.9){
        return "Cuadro de Obesidad Moderada";

    } else if ($imc >= 35 && $imc <= 39.9){
        return "Cuadro de Obsesidad Severa";

    } else {
        return "Cuadro de Obesidad Mórbida";
    }

}
?>