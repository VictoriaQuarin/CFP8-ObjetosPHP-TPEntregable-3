<?php

$peso = $_REQUEST['peso'];
$altura = $_REQUEST['altura'];
$calculoIMC = $_REQUEST['calculoIMC'];
$calculoResultado = $_REQUEST['calculoResultado'];


function calculoIMC(int $peso, int $altura): float {
    return $peso / ($altura * $altura);
}


function calculoResultado(float $imc) : string {
    if ($imc <= 15) {
        return "Cuadro de Delgadez muy severa";  

    } if else ($imc >= 15 && $imc <= 15.9){
        return "Cuadro de Delgadez severa";

    } if else ($imc >= 16 && $imc <= 18.4){
        return "Cuadro de Delgadez";

    } if else ($imc >= 18.5 && $imc <= 24.9){
        return "Valor Normal";

    } if else ($imc >= 25 && $imc <= 29.9){
        return "Cuadro de Sobrepeso";

    } if else ($imc >= 30 && $imc <= 34.9){
        return "Cuadro de Obesidad Moderada";

    } if else ($imc >= 35 && $imc <= 39.9){
        return "Cuadro de Obsesidad Severa";

    } else {
        return "Cuadro de Obesidad Mórbida";
    }


}
?>