<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cálculo del IMC</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- http://localhost/objetos/tpe3/calculo_IMC.php -->
    <h1>Cálculo del IMC</h1>
    <form>
        <table>
            <tr>
                <td><label class="etiqueta">Peso (en kg.): </label></td>
                <td>
                    <input type="number" name="peso" id="peso" class="input texto" required minlength="1" maxlenght="5">
                </td>
            </tr>
            <tr>
                <td><label class="etiqueta">Altura (en m.): </label></td>
                <td>
                    <input type="number" name="altura" id="altura" class="input texto" required minlength="1" maxlenght="5">
                </td>
            </tr>
            <tr>
                <td><input type="reset"  class="boton botonBorrar" value="Borrar"></td>
                <td><input type="button" onclick="calculoIMC()" class="boton botonEnviar" value="Calcular"></td>
            </tr>
            <tr>
                <td><label class="etiqueta">Resultado: </label></td>
                <td>
                    <div class="input text" id="resultado">
                    </div>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>